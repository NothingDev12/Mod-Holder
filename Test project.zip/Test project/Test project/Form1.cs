using System.Diagnostics;
using System.Windows.Forms;

namespace Test_project
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void OpenUrl(string url)
        {
            ProcessStartInfo psi = new ProcessStartInfo
            {
                FileName = url,
                UseShellExecute = true
            };
            Process.Start(psi);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenUrl("https://github.com/KyleTheScientist/Bark");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            OpenUrl("https://github.com/legoandmars/Utilla");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            OpenUrl("https://github.com/BepInEx/BepInEx");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            OpenUrl("https://github.com/Chin0303/Monke-Dimensions/releases/tag/1.3.2");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            
        }
    }
}
